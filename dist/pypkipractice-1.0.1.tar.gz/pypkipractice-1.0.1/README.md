# Placeholder README file

Hi! This Repo is under development, I'm just cloning it here to practice using tags and pushing.

Use the NOTES.md file to get an idea of what this project is about!
